﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double vlrRaio;
            if (!double.TryParse(txtRaio.Text, out vlrRaio))
            {
                MessageBox.Show("Raio inválido!");
            }
            else
            {
                if (vlrRaio <= 0)
                {
                    MessageBox.Show("O Raio deve ser maior que 0");
                }
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double vlrAltura;
            if (!double.TryParse(txtAltura.Text, out vlrAltura))
            {
                MessageBox.Show("Altura inválido!");
            }
            else
            {
                if (vlrAltura <= 0)
                {
                    MessageBox.Show("A Altura deve ser maior que 0");
                }
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double vlrRaio, vlrAltura;
            if ((!double.TryParse(txtRaio.Text, out vlrRaio))
            || (!double.TryParse(txtAltura.Text, out vlrAltura)))
            {
                MessageBox.Show("Valores inválidos!");
                txtRaio.Focus();
            }
            else if (vlrRaio <= 0 || vlrAltura <= 0)
            {
                MessageBox.Show("Valores devem ser maior que zero!");
                txtRaio.Focus();

            }
            else
            {
                double volume;
                volume = Math.PI * Math.Pow(vlrRaio, 2) * vlrAltura;
                txtVolume.Text = volume.ToString("N2");
                }
            }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
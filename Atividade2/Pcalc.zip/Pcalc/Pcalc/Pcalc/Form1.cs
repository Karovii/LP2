﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Calculator : Form
    {
        double num1, num2, resultado;
        public Calculator()
        {
            InitializeComponent();
        }

        private void txtbx1_Validated(object sender, EventArgs e)
        {
     
            if (!double.TryParse(txtbx1.Text, out num1))
            {
                    MessageBox.Show("Número 1 inválido!");
                    txtbx1.Focus();
            }
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            txtbxResult.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = num1 * num2;
            txtbxResult.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Não é possivel dividir por 0", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtbx2.Text = "";
                txtbx2.Focus();
            }
            else {
                resultado = num1 / num2;
                txtbxResult.Text = resultado.ToString();
                }
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtbx1.Text = "";
            txtbx2.Text = "";
            txtbxResult.Text = "";
            txtbx1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void txtbx2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbx2.Text, out num2))
            {
                MessageBox.Show("Número 2 inválido!");
                txtbx2.Focus();
            }
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            resultado =  num1 + num2;
            txtbxResult.Text = resultado.ToString();
        }
    }
}


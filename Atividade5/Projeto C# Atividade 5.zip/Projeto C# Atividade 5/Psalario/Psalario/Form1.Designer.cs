﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.btnDesc = new System.Windows.Forms.Button();
            this.mskbxSal = new System.Windows.Forms.MaskedTextBox();
            this.txtbxNome = new System.Windows.Forms.TextBox();
            this.lblSal = new System.Windows.Forms.Label();
            this.nupFilhos = new System.Windows.Forms.NumericUpDown();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblInss = new System.Windows.Forms.Label();
            this.txtbxInss = new System.Windows.Forms.TextBox();
            this.txtbxIrpf = new System.Windows.Forms.TextBox();
            this.lblIrpf = new System.Windows.Forms.Label();
            this.txtbxFam = new System.Windows.Forms.TextBox();
            this.lblFamilia = new System.Windows.Forms.Label();
            this.txtbxLiqui = new System.Windows.Forms.TextBox();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.txtbxDescInss = new System.Windows.Forms.TextBox();
            this.lblDescInss = new System.Windows.Forms.Label();
            this.txtbxDescIrpf = new System.Windows.Forms.TextBox();
            this.lblDescIrpf = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nupFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(26, 30);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(153, 21);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome funcionário:";
            // 
            // btnDesc
            // 
            this.btnDesc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDesc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDesc.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesc.Location = new System.Drawing.Point(30, 230);
            this.btnDesc.Name = "btnDesc";
            this.btnDesc.Size = new System.Drawing.Size(338, 35);
            this.btnDesc.TabIndex = 1;
            this.btnDesc.Text = "Verificar Desconto";
            this.btnDesc.UseVisualStyleBackColor = false;
            this.btnDesc.Click += new System.EventHandler(this.btnDesc_Click);
            // 
            // mskbxSal
            // 
            this.mskbxSal.Location = new System.Drawing.Point(198, 97);
            this.mskbxSal.Mask = "999000.00";
            this.mskbxSal.Name = "mskbxSal";
            this.mskbxSal.Size = new System.Drawing.Size(170, 20);
            this.mskbxSal.TabIndex = 2;
            // 
            // txtbxNome
            // 
            this.txtbxNome.Location = new System.Drawing.Point(198, 33);
            this.txtbxNome.Name = "txtbxNome";
            this.txtbxNome.Size = new System.Drawing.Size(507, 20);
            this.txtbxNome.TabIndex = 3;
            this.txtbxNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbxNome_KeyPress);
            this.txtbxNome.Validated += new System.EventHandler(this.txtbxNome_Validated);
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSal.Location = new System.Drawing.Point(26, 94);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(112, 21);
            this.lblSal.TabIndex = 4;
            this.lblSal.Text = "Salário bruto:";
            // 
            // nupFilhos
            // 
            this.nupFilhos.Location = new System.Drawing.Point(198, 164);
            this.nupFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nupFilhos.Name = "nupFilhos";
            this.nupFilhos.Size = new System.Drawing.Size(170, 20);
            this.nupFilhos.TabIndex = 5;
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilhos.Location = new System.Drawing.Point(26, 160);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(147, 21);
            this.lblFilhos.TabIndex = 6;
            this.lblFilhos.Text = "Número de filhos:";
            // 
            // lblInss
            // 
            this.lblInss.AutoSize = true;
            this.lblInss.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInss.Location = new System.Drawing.Point(26, 308);
            this.lblInss.Name = "lblInss";
            this.lblInss.Size = new System.Drawing.Size(119, 21);
            this.lblInss.TabIndex = 7;
            this.lblInss.Text = "Alíquota INSS:";
            // 
            // txtbxInss
            // 
            this.txtbxInss.Enabled = false;
            this.txtbxInss.Location = new System.Drawing.Point(198, 308);
            this.txtbxInss.Name = "txtbxInss";
            this.txtbxInss.Size = new System.Drawing.Size(170, 20);
            this.txtbxInss.TabIndex = 8;
            // 
            // txtbxIrpf
            // 
            this.txtbxIrpf.Enabled = false;
            this.txtbxIrpf.Location = new System.Drawing.Point(198, 368);
            this.txtbxIrpf.Name = "txtbxIrpf";
            this.txtbxIrpf.Size = new System.Drawing.Size(170, 20);
            this.txtbxIrpf.TabIndex = 10;
            // 
            // lblIrpf
            // 
            this.lblIrpf.AutoSize = true;
            this.lblIrpf.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIrpf.Location = new System.Drawing.Point(26, 368);
            this.lblIrpf.Name = "lblIrpf";
            this.lblIrpf.Size = new System.Drawing.Size(117, 21);
            this.lblIrpf.TabIndex = 9;
            this.lblIrpf.Text = "Alíquota IRPF:";
            // 
            // txtbxFam
            // 
            this.txtbxFam.Enabled = false;
            this.txtbxFam.Location = new System.Drawing.Point(198, 424);
            this.txtbxFam.Name = "txtbxFam";
            this.txtbxFam.Size = new System.Drawing.Size(170, 20);
            this.txtbxFam.TabIndex = 12;
            // 
            // lblFamilia
            // 
            this.lblFamilia.AutoSize = true;
            this.lblFamilia.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFamilia.Location = new System.Drawing.Point(26, 424);
            this.lblFamilia.Name = "lblFamilia";
            this.lblFamilia.Size = new System.Drawing.Size(124, 21);
            this.lblFamilia.TabIndex = 11;
            this.lblFamilia.Text = "Salário Família:";
            // 
            // txtbxLiqui
            // 
            this.txtbxLiqui.Enabled = false;
            this.txtbxLiqui.Location = new System.Drawing.Point(198, 478);
            this.txtbxLiqui.Name = "txtbxLiqui";
            this.txtbxLiqui.Size = new System.Drawing.Size(170, 20);
            this.txtbxLiqui.TabIndex = 14;
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalLiquido.Location = new System.Drawing.Point(26, 478);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(126, 21);
            this.lblSalLiquido.TabIndex = 13;
            this.lblSalLiquido.Text = "Salário Liquido:";
            // 
            // txtbxDescInss
            // 
            this.txtbxDescInss.Enabled = false;
            this.txtbxDescInss.Location = new System.Drawing.Point(705, 308);
            this.txtbxDescInss.Name = "txtbxDescInss";
            this.txtbxDescInss.Size = new System.Drawing.Size(170, 20);
            this.txtbxDescInss.TabIndex = 16;
            // 
            // lblDescInss
            // 
            this.lblDescInss.AutoSize = true;
            this.lblDescInss.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescInss.Location = new System.Drawing.Point(533, 305);
            this.lblDescInss.Name = "lblDescInss";
            this.lblDescInss.Size = new System.Drawing.Size(127, 21);
            this.lblDescInss.TabIndex = 15;
            this.lblDescInss.Text = "Desconto INSS:";
            // 
            // txtbxDescIrpf
            // 
            this.txtbxDescIrpf.Enabled = false;
            this.txtbxDescIrpf.Location = new System.Drawing.Point(705, 368);
            this.txtbxDescIrpf.Name = "txtbxDescIrpf";
            this.txtbxDescIrpf.Size = new System.Drawing.Size(170, 20);
            this.txtbxDescIrpf.TabIndex = 18;
            // 
            // lblDescIrpf
            // 
            this.lblDescIrpf.AutoSize = true;
            this.lblDescIrpf.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescIrpf.Location = new System.Drawing.Point(533, 368);
            this.lblDescIrpf.Name = "lblDescIrpf";
            this.lblDescIrpf.Size = new System.Drawing.Size(125, 21);
            this.lblDescIrpf.TabIndex = 17;
            this.lblDescIrpf.Text = "Desconto IRPF:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 608);
            this.Controls.Add(this.txtbxDescIrpf);
            this.Controls.Add(this.lblDescIrpf);
            this.Controls.Add(this.txtbxDescInss);
            this.Controls.Add(this.lblDescInss);
            this.Controls.Add(this.txtbxLiqui);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.txtbxFam);
            this.Controls.Add(this.lblFamilia);
            this.Controls.Add(this.txtbxIrpf);
            this.Controls.Add(this.lblIrpf);
            this.Controls.Add(this.txtbxInss);
            this.Controls.Add(this.lblInss);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.nupFilhos);
            this.Controls.Add(this.lblSal);
            this.Controls.Add(this.txtbxNome);
            this.Controls.Add(this.mskbxSal);
            this.Controls.Add(this.btnDesc);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Salario";
            ((System.ComponentModel.ISupportInitialize)(this.nupFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Button btnDesc;
        private System.Windows.Forms.MaskedTextBox mskbxSal;
        private System.Windows.Forms.TextBox txtbxNome;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.NumericUpDown nupFilhos;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblInss;
        private System.Windows.Forms.TextBox txtbxInss;
        private System.Windows.Forms.TextBox txtbxIrpf;
        private System.Windows.Forms.Label lblIrpf;
        private System.Windows.Forms.TextBox txtbxFam;
        private System.Windows.Forms.Label lblFamilia;
        private System.Windows.Forms.TextBox txtbxLiqui;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.TextBox txtbxDescInss;
        private System.Windows.Forms.Label lblDescInss;
        private System.Windows.Forms.TextBox txtbxDescIrpf;
        private System.Windows.Forms.Label lblDescIrpf;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDesc_Click(object sender, EventArgs e)
        {
            double vlrBruto, qtdFilhos, DescInss=0, DescIrpf=0, SalFam=0, vlrLiquido;

            qtdFilhos = Convert.ToDouble(nupFilhos.Value);
            double.TryParse(mskbxSal.Text, out vlrBruto);

            //INSS
            if (vlrBruto <= 800.47)
            {
                txtbxInss.Text = "7,65%";
                DescInss = 0.0765 * vlrBruto;
                txtbxDescInss.Text = $"R$ {DescInss}";
            }
            else if (vlrBruto <= 1050)
            {
                txtbxInss.Text = "8,65%";
                DescInss = 0.0865 * vlrBruto;
                txtbxDescInss.Text = $"R$ {DescInss}";
            }
            else if (vlrBruto <= 1400.77)
            {
                txtbxInss.Text = "9,00%";
                DescInss = 0.09 * vlrBruto;
                txtbxDescInss.Text = $"R$ {DescInss}";
            }
            else if (vlrBruto <= 2801.56)
            {
                txtbxInss.Text = "11,00%";
                DescInss = 0.011 * vlrBruto;
                txtbxDescInss.Text = $"R$ {DescInss}";
            }
            else if (vlrBruto > 2801.56)
            {
                txtbxInss.Text = "Teto";
                DescInss = 308.17;
                txtbxDescInss.Text = $"R$ {DescInss}";
            }

            //IRPF
            if (vlrBruto <= 1257.12)
            {
                txtbxIrpf.Text = "Isento";
                DescIrpf = 0;
                txtbxDescIrpf.Text = $"R$ {DescIrpf}";
            }
            else if (vlrBruto <= 2512.08)
            {
                txtbxIrpf.Text = "15,00%";
                DescIrpf = 0.15 * vlrBruto;
                txtbxDescIrpf.Text = $"R$ {DescIrpf}";
            }
            else if (vlrBruto > 2512.08)
            {
                txtbxIrpf.Text = "27,50%";
                DescIrpf = 0.275 * vlrBruto;
                txtbxDescIrpf.Text = $"R$ {DescIrpf}";
            }

            //Salario Familia
            if (vlrBruto <= 435.52)
            {
                SalFam = 22.33 * qtdFilhos;
                txtbxFam.Text = $"R$ {SalFam}";
            }
            else if (vlrBruto <= 654.61)
            {
                SalFam = 15.74 * qtdFilhos;
                txtbxFam.Text = $"R$ {SalFam}";
            }
            else if (vlrBruto > 654.61)
            {
                SalFam = 0 * qtdFilhos;
                txtbxFam.Text = "0";
            }

            vlrLiquido = vlrBruto - DescInss - DescIrpf + SalFam;

            txtbxLiqui.Text = vlrLiquido.ToString();

        }

        private void txtbxNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter Inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtbxNome_Validated(object sender, EventArgs e)
        {
            if (txtbxNome.Text == "")
            {
                MessageBox.Show("Nome Inválido");
                txtbxNome.Focus();
            }
        }
    }
}

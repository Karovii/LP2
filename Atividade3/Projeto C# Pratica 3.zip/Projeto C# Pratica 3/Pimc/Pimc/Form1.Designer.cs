﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblPeso = new System.Windows.Forms.Label();
            this.lblAltura = new System.Windows.Forms.Label();
            this.msktxtbxAltura = new System.Windows.Forms.MaskedTextBox();
            this.mskdtxtbxPeso = new System.Windows.Forms.MaskedTextBox();
            this.txtbxImc = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft YaHei", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(102, 450);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(231, 109);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeso.Location = new System.Drawing.Point(12, 112);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(105, 26);
            this.lblPeso.TabIndex = 1;
            this.lblPeso.Text = "Peso (kg):";
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltura.Location = new System.Drawing.Point(12, 249);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(115, 26);
            this.lblAltura.TabIndex = 2;
            this.lblAltura.Text = "Altura (m):";
            // 
            // msktxtbxAltura
            // 
            this.msktxtbxAltura.Location = new System.Drawing.Point(184, 255);
            this.msktxtbxAltura.Mask = "0.00";
            this.msktxtbxAltura.Name = "msktxtbxAltura";
            this.msktxtbxAltura.Size = new System.Drawing.Size(239, 20);
            this.msktxtbxAltura.TabIndex = 4;
            this.msktxtbxAltura.Validated += new System.EventHandler(this.msktxtbxAltura_Validated);
            // 
            // mskdtxtbxPeso
            // 
            this.mskdtxtbxPeso.Location = new System.Drawing.Point(184, 118);
            this.mskdtxtbxPeso.Mask = "900.00";
            this.mskdtxtbxPeso.Name = "mskdtxtbxPeso";
            this.mskdtxtbxPeso.Size = new System.Drawing.Size(239, 20);
            this.mskdtxtbxPeso.TabIndex = 5;
            this.mskdtxtbxPeso.Validated += new System.EventHandler(this.mskdtxtbxPeso_Validated);
            // 
            // txtbxImc
            // 
            this.txtbxImc.Enabled = false;
            this.txtbxImc.Font = new System.Drawing.Font("Microsoft YaHei", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxImc.Location = new System.Drawing.Point(102, 361);
            this.txtbxImc.Name = "txtbxImc";
            this.txtbxImc.Size = new System.Drawing.Size(231, 54);
            this.txtbxImc.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 571);
            this.Controls.Add(this.txtbxImc);
            this.Controls.Add(this.mskdtxtbxPeso);
            this.Controls.Add(this.msktxtbxAltura);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.lblPeso);
            this.Controls.Add(this.btnCalcular);
            this.Name = "Form1";
            this.Text = "IMC Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.MaskedTextBox msktxtbxAltura;
        private System.Windows.Forms.MaskedTextBox mskdtxtbxPeso;
        private System.Windows.Forms.TextBox txtbxImc;
    }
}


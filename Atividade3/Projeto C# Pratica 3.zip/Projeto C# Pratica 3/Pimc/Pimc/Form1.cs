﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mskdtxtbxPeso_Validated(object sender, EventArgs e)
        {
            double vlrPeso;
            if (!double.TryParse(mskdtxtbxPeso.Text, out vlrPeso))
            {
                MessageBox.Show("Peso inválido!");
                mskdtxtbxPeso.Focus();
            }
            else
            {
                if (vlrPeso <= 0)
                {
                    MessageBox.Show("O Peso deve ser maior que 0");
                    mskdtxtbxPeso.Focus();
                }
            }
        }

        private void msktxtbxAltura_Validated(object sender, EventArgs e)
        {
            double vlrAltura;
            if (!double.TryParse(msktxtbxAltura.Text, out vlrAltura))
            {
                MessageBox.Show("Altura inválida!");
                msktxtbxAltura.Focus();
            }
            else
            {
                if (vlrAltura <= 0)
                {
                    MessageBox.Show("A Altura deve ser maior que 0");
                    msktxtbxAltura.Focus();
                }
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double imc, vlrAltura, vlrPeso;
            double.TryParse(msktxtbxAltura.Text, out vlrAltura);
            double.TryParse(mskdtxtbxPeso.Text, out vlrPeso);
            imc = vlrPeso / Math.Pow(vlrAltura, 2);
            txtbxImc.Text = imc.ToString("N2");
            imc = Math.Round(imc);
            if (imc < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            if (imc >= 18.5 && imc <= 24.9)
            {
                MessageBox.Show("Normal");
            }
            if (imc >= 25 &&  imc <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            if (imc >= 30 && imc <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            if (imc >= 40)
            {
                MessageBox.Show("Obesidade grave");
            }
        }
    }
}

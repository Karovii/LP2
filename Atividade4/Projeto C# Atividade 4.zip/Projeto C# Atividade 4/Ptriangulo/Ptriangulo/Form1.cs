﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Triangulos : Form
    {
        public Triangulos()
        {
            InitializeComponent();
        }

        private void txtbxLadoA_Validated(object sender, EventArgs e)
        {
            double vlrLadoA;
            if (!double.TryParse(txtbxLadoA.Text, out vlrLadoA))
            {
                MessageBox.Show("Lado A inválido!");
                txtbxLadoA.Focus();
            }
            else
            {
                if (vlrLadoA <= 0)
                {
                    MessageBox.Show("Lado A deve ser maior que 0");
                    txtbxLadoA.Focus();
                }
            }
        }

        private void txtbxLadoB_Validated(object sender, EventArgs e)
        {
            double vlrLadoB;
            if (!double.TryParse(txtbxLadoB.Text, out vlrLadoB))
            {
                MessageBox.Show("Lado B inválido!");
                txtbxLadoB.Focus();
            }
            else
            {
                if (vlrLadoB <= 0)
                {
                    MessageBox.Show("Lado B deve ser maior que 0");
                    txtbxLadoB.Focus();
                }
            }
        }

        private void txtbxLadoC_Validated(object sender, EventArgs e)
        {
            double vlrLadoC;
            if (!double.TryParse(txtbxLadoC.Text, out vlrLadoC))
            {
                MessageBox.Show("Lado C inválido!");
                txtbxLadoC.Focus();
            }
            else
            {
                if (vlrLadoC <= 0)
                {
                    MessageBox.Show("Lado C deve ser maior que 0");
                    txtbxLadoC.Focus();
                }
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double vlrLadoA, vlrLadoB, vlrLadoC;
            double.TryParse(txtbxLadoA.Text, out vlrLadoA);
            double.TryParse(txtbxLadoB.Text, out vlrLadoB);
            double.TryParse(txtbxLadoC.Text, out vlrLadoC);
            
            if ((Math.Abs(vlrLadoB-vlrLadoC) < vlrLadoA && vlrLadoA < vlrLadoB + vlrLadoC) && (Math.Abs(vlrLadoA - vlrLadoC) < vlrLadoB && vlrLadoB < vlrLadoA + vlrLadoC) && (Math.Abs(vlrLadoA - vlrLadoB) < vlrLadoC && vlrLadoC < vlrLadoA + vlrLadoB))
            {
              if (vlrLadoA == vlrLadoB && vlrLadoB == vlrLadoC)
               {
                 txtTipoTriangulo.Text = "Trinagulo Equilatero";
               }
              if (vlrLadoA != vlrLadoB && vlrLadoB != vlrLadoC && vlrLadoA != vlrLadoC)
               {
                 txtTipoTriangulo.Text = "Triangulo Escaleno";
               }
              if ((vlrLadoB == vlrLadoA && vlrLadoA != vlrLadoC) || (vlrLadoA == vlrLadoC && vlrLadoB != vlrLadoC) || (vlrLadoB == vlrLadoC && vlrLadoB != vlrLadoA))
               {
                 txtTipoTriangulo.Text = "Triangulo Isosceles";
               }
            }
            else
             {
              MessageBox.Show("Isso não é um triangulo!!!");
              txtbxLadoA.Focus();
             }

        }
    }
}
